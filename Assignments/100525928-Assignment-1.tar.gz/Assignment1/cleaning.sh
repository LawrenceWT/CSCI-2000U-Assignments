#!/bin/bash
for f in ~/Downloads/Assignments/Assignment1/cleaned_data/*
do
mv "$f" "$f.txt"
done
