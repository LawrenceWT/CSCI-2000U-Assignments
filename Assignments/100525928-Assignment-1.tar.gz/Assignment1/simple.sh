#!/bin/bash
# This is a comment
echo "The number of arguements is $#"
echo "The arguements are $*"
echo "The first arguement is $1"
echo "My process number is $$"
echo "Enter a number from the keyboard: "
read number
echo "The number you entered was $number"
